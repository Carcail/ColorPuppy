package com.carmencaicedo.colorpuppy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Pet> pets;

    private RecyclerView petList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        petList = (RecyclerView) findViewById(R.id.rvPets);

        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        petList.setLayoutManager(llm);

        initialPetList();
        initialAdapter();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.mOp1:
                Toast.makeText(this,"Opción 1",Toast.LENGTH_SHORT).show();
                break;
            case R.id.mOp2:
                Toast.makeText(this,"Opción 2",Toast.LENGTH_SHORT).show();
                break;
            case R.id.bt_FavPets:
                Intent intent = new Intent(MainActivity.this,Favorite_Pets.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public PetAdapter adapter;

    public void initialAdapter(){
        adapter = new PetAdapter(pets, this);
        petList.setAdapter(adapter);
    }

    public void initialPetList(){

        pets = new ArrayList<Pet>();

            pets.add(new Pet(R.drawable.bunny,"Bunny",17));
            pets.add(new Pet(R.drawable.carol,"Carol",16));
            pets.add(new Pet(R.drawable.chams,"Chams",14));
            pets.add(new Pet(R.drawable.kitty,"Kitty",10));
            pets.add(new Pet(R.drawable.leonidas,"Leonidas",12));
            pets.add(new Pet(R.drawable.spike,"Spike",8));
            pets.add(new Pet(R.drawable.teddy,"Teddy",18));
            pets.add(new Pet(R.drawable.wolf,"Wolf",15));
    }


}