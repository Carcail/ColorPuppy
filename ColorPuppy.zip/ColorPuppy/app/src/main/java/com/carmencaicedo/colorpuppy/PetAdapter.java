package com.carmencaicedo.colorpuppy;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PetAdapter extends RecyclerView.Adapter <PetAdapter.PetViewHolder> {

    ArrayList<Pet> pets;
    Activity activity;

    public PetAdapter(ArrayList<Pet> pets, Activity activity){
        this.pets = pets;
        this.activity = activity;
    }

    @NonNull
    @Override
    public PetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_pet, parent, false);
        return new PetViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PetViewHolder petViewHolder, int position) {
        final Pet pet = pets.get(position);

        petViewHolder.ivCvPhoto.setImageResource(pet.getPhoto());
        petViewHolder.tvCvName.setText(pet.getName());
        petViewHolder.tvCvCount.setText(String.valueOf(pet.getCnt()));
        petViewHolder.ivCvBoneLk.setOnClickListener(new View.OnClickListener() {
            int count;
            @Override
            public void onClick(View v) {
                count = 0;
                pets.get(position).setCnt(pets.get(position).getCnt()+1);
                petViewHolder.tvCvCount.setText(String.valueOf(pets.get(position).getCnt()));
           }
        });
    }

    @Override
    public int getItemCount() {
        return pets.size();
    }

    public static class PetViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivCvPhoto;
        private TextView tvCvAttri;
        private ImageButton ivCvBoneLk;
        private TextView tvCvName;
        private TextView tvCvCount;
        private ImageView ivCvBoneCnt;

        public PetViewHolder(@NonNull View itemView) {
            super(itemView);

            ivCvPhoto   = (ImageView) itemView.findViewById(R.id.ivCvPhoto);
            tvCvAttri   = (TextView) itemView.findViewById(R.id.tvCvAttri);
            ivCvBoneLk  = (ImageButton) itemView.findViewById(R.id.ivCvBoneLk);
            tvCvName    = (TextView) itemView.findViewById(R.id.tvCvName);
            tvCvCount   = (TextView) itemView.findViewById(R.id.tvCvCount);
            ivCvBoneCnt = (ImageView) itemView.findViewById(R.id.ivCvBoneCnt);

        }
    }
}


