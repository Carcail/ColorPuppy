package com.carmencaicedo.colorpuppy;

public class Pet {

    private int photo;
    private String name;
    private int cnt;

    public Pet() {
    }

    public Pet(int photo, String name, int cnt){
        this.photo  = photo;
        this.name   = name;
        this.cnt = cnt;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCnt() { return cnt; }

    public void setCnt(int cnt) { this.cnt = cnt; }
}
